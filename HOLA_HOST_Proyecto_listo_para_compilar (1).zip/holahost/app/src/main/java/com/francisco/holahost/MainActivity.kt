package com.francisco.holahost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080B14)
private val Panel = Color(0xCC151D31)
private val Panel2 = Color(0xFF11182A)
private val Blue = Color(0xFF36B7FF)
private val Cyan = Color(0xFF76E4FF)
private val Muted = Color(0xFFAAB8D0)
private val White = Color(0xFFF5F8FF)
private val Border = Color(0x443CAFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,11,20)
        window.navigationBarColor = android.graphics.Color.rgb(8,11,20)
        setContent { HostApp() }
    }
}

@Composable
fun HostApp() {
    var tab by remember { mutableStateOf("Inicio") }
    var maxPlayers by remember { mutableStateOf("10") }
    var serverName by remember { mutableStateOf("Francisco's Realm") }
    var isPublic by remember { mutableStateOf(true) }
    var allowCheats by remember { mutableStateOf(false) }
    var worldName by remember { mutableStateOf("Mundo principal") }
    var adminName by remember { mutableStateOf("") }
    var admins by remember { mutableStateOf(listOf("Francisco")) }
    var note by remember { mutableStateOf("Motor Bedrock no integrado") }
    var showInfo by remember { mutableStateOf(false) }
    val bg = Brush.verticalGradient(listOf(Color(0xFF101D37), Bg, Color(0xFF090D19)))

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, secondary = Cyan, background = Bg, surface = Panel2,
        onPrimary = Bg, onBackground = White, onSurface = White
    )) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(start=20.dp,end=20.dp,top=18.dp,bottom=12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(listOf(Blue, Color(0xFF655DFF))))
                            .border(1.dp, Color.White.copy(alpha=.35f), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("H", color=White, fontSize=27.sp, fontWeight=FontWeight.Black) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("HOLA HOST", fontSize=21.sp, fontWeight=FontWeight.Black, letterSpacing=1.5.sp)
                        Text("BY FRANCISCO  •  BEDROCK", fontSize=10.sp, color=Muted, letterSpacing=1.1.sp)
                    }
                    Box(Modifier.clip(CircleShape).background(Color(0x2236B7FF)).border(1.dp, Border, CircleShape).padding(horizontal=11.dp, vertical=7.dp)) {
                        Text("BETA", color=Cyan, fontSize=11.sp, fontWeight=FontWeight.Bold)
                    }
                }
                when(tab) {
                    "Inicio" -> LazyColumn(contentPadding=PaddingValues(start=18.dp,end=18.dp,bottom=100.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                        item {
                            GlassCard {
                                Text("TU MUNDO, TUS REGLAS", color=Cyan, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.6.sp)
                                Spacer(Modifier.height(12.dp))
                                Text("Tu servidor.\nTu aventura.", fontSize=34.sp, lineHeight=37.sp, fontWeight=FontWeight.ExtraBold)
                                Spacer(Modifier.height(8.dp))
                                Text("Panel de control Bedrock con una estética Liquid Glass en negro y azul eléctrico.", color=Muted, fontSize=14.sp, lineHeight=20.sp)
                                Spacer(Modifier.height(18.dp))
                                Row(verticalAlignment=Alignment.CenterVertically) {
                                    Box(Modifier.size(9.dp).clip(CircleShape).background(Color(0xFFFFC857)))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Motor de servidor no instalado", color=Color(0xFFFFD27A), fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                                }
                                Spacer(Modifier.height(16.dp))
                                Button(onClick={showInfo=true}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Blue, contentColor=Bg), shape=RoundedCornerShape(15.dp)) {
                                    Text("¿Qué necesito para alojar?", fontWeight=FontWeight.Bold)
                                }
                            }
                        }
                        item {
                            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                                MetricCard("JUGADORES","${maxPlayers.toIntOrNull() ?: 10} máx.","♟",Modifier.weight(1f))
                                MetricCard("ACCESO",if(isPublic) "Público" else "Privado","⌁",Modifier.weight(1f))
                            }
                        }
                        item { SectionTitle("Accesos rápidos","GESTIÓN") }
                        item {
                            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                                QuickCard("⚙","Ajustes","Límite y acceso",Modifier.weight(1f)){tab="Ajustes"}
                                QuickCard("♙","Admins","${admins.size} autorizados",Modifier.weight(1f)){tab="Admins"}
                            }
                        }
                        item {
                            GlassCard {
                                Text("ESTADO DEL PROYECTO", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.3.sp)
                                Spacer(Modifier.height(10.dp))
                                Text("Interfaz y configuración local listas para ampliar.", fontSize=15.sp, fontWeight=FontWeight.SemiBold)
                                Spacer(Modifier.height(5.dp))
                                Text("Esta versión no inicia partidas ni abre puertos: todavía necesita un motor Bedrock compatible con Android.", color=Muted, fontSize=13.sp, lineHeight=19.sp)
                            }
                        }
                    }
                    "Ajustes" -> LazyColumn(contentPadding=PaddingValues(18.dp,8.dp,18.dp,100.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                        item { SectionTitle("Configuración del servidor","CONFIGURACIÓN") }
                        item {
                            GlassCard {
                                Label("NOMBRE DEL SERVIDOR")
                                InputField(serverName,{serverName=it},"Nombre del mundo/servidor")
                                Spacer(Modifier.height(16.dp))
                                Label("MÁXIMO DE JUGADORES")
                                InputField(maxPlayers,{maxPlayers=it.filter(Char::isDigit).take(3)},"Ej. 10",true)
                                Text("El límite se guarda en esta pantalla; no se aplica a un servidor real hasta integrar el motor.", color=Muted, fontSize=11.sp)
                                Spacer(Modifier.height(16.dp))
                                SettingToggle("Acceso público","Permitir que cualquier persona autorizada por la red pueda intentar entrar.",isPublic){isPublic=it}
                                Divider(color=Border, modifier=Modifier.padding(vertical=10.dp))
                                SettingToggle("Permitir trucos","Configuración prevista para el mundo.",allowCheats){allowCheats=it}
                                Spacer(Modifier.height(12.dp))
                                Button(onClick={note="Configuración local actualizada"}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Blue,contentColor=Bg), shape=RoundedCornerShape(14.dp)) { Text("Guardar configuración",fontWeight=FontWeight.Bold) }
                                Text(note, color=Muted, fontSize=11.sp, modifier=Modifier.padding(top=8.dp))
                            }
                        }
                        item {
                            GlassCard {
                                Label("MUNDO")
                                InputField(worldName,{worldName=it},"Nombre del mundo")
                                Spacer(Modifier.height(10.dp))
                                Text("Cargar mundos, backups y paquetes de recursos requiere integrar el motor de servidor y su formato de archivos.", color=Muted, fontSize=13.sp, lineHeight=19.sp)
                            }
                        }
                    }
                    "Admins" -> LazyColumn(contentPadding=PaddingValues(18.dp,8.dp,18.dp,100.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                        item { SectionTitle("Administradores","PERMISOS") }
                        item {
                            GlassCard {
                                Text("Administra la lista local de nombres.", color=Muted, fontSize=13.sp)
                                Spacer(Modifier.height(12.dp))
                                InputField(adminName,{adminName=it},"Gamertag del jugador")
                                Spacer(Modifier.height(8.dp))
                                Button(onClick={val n=adminName.trim(); if(n.isNotEmpty() && !admins.any{it.equals(n,true)}) admins=admins+n; adminName=""}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Blue,contentColor=Bg), shape=RoundedCornerShape(14.dp)) { Text("＋ Añadir administrador",fontWeight=FontWeight.Bold) }
                            }
                        }
                        items(admins.size) { i ->
                            GlassCard {
                                Row(verticalAlignment=Alignment.CenterVertically) {
                                    Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0x2236B7FF)),contentAlignment=Alignment.Center){Text("♙",color=Cyan,fontSize=20.sp)}
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) { Text(admins[i],fontWeight=FontWeight.Bold); Text(if(i==0) "Creador" else "Admin local",color=Muted,fontSize=12.sp) }
                                    if(i>0) TextButton(onClick={admins=admins.filterIndexed{idx,_->idx!=i}}){Text("Quitar",color=Color(0xFFFF879D))}
                                }
                            }
                        }
                        item { Text("Nota: esta lista es una configuración local; los permisos reales se aplicarán cuando exista un servidor conectado.", color=Muted, fontSize=12.sp, lineHeight=18.sp) }
                    }
                    "Recursos" -> LazyColumn(contentPadding=PaddingValues(18.dp,8.dp,18.dp,100.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                        item { SectionTitle("Mundo y recursos","CONTENIDO") }
                        item { ResourceCard("▧","Mundos y copias de seguridad","Preparado para añadir importación de mundos, exportación y copias de seguridad cuando se integre un motor compatible.") }
                        item { ResourceCard("✦","Paquetes de recursos","Bedrock admite paquetes de recursos, pero su instalación debe gestionarse con el motor y la versión del servidor.") }
                        item { ResourceCard("⌘","Complementos","Los plugins dependen del software elegido. Algunos motores alternativos no reproducen toda la experiencia vanilla.") }
                        item { ResourceCard("⌁","Conexión pública","Para acceso desde Internet hacen falta red estable, puerto UDP de Bedrock (normalmente 19132), y que el proveedor de red permita conexiones entrantes.") }
                    }
                    else -> {}
                }
            }
            if(showInfo) {
                Box(Modifier.fillMaxSize().background(Color(0x99030710)).clickable{showInfo=false},contentAlignment=Alignment.Center) {
                    GlassCard(Modifier.fillMaxWidth().padding(22.dp)) {
                        Text("Antes de alojar",fontSize=22.sp,fontWeight=FontWeight.ExtraBold)
                        Spacer(Modifier.height(10.dp))
                        Text("El servidor oficial Bedrock se publica para Windows y Ubuntu Linux, no como una app Android oficial. Esta app nativa es el panel; aún falta integrar un motor compatible con Android.", color=Muted, fontSize=14.sp, lineHeight=21.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("Un servidor público también necesita que Android no lo suspenda, suficiente RAM, almacenamiento, conexión estable y una ruta de red accesible desde fuera.", color=Muted, fontSize=14.sp, lineHeight=21.sp)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick={showInfo=false}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Blue,contentColor=Bg)){Text("Entendido")}
                    }
                }
            }
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal=12.dp, vertical=10.dp)
                .clip(RoundedCornerShape(23.dp)).background(Color(0xE6111728)).border(1.dp,Color(0x443CAFFF),RoundedCornerShape(23.dp)).padding(6.dp),
                horizontalArrangement=Arrangement.SpaceEvenly) {
                NavItem("⌂","Inicio",tab== "Inicio"){tab="Inicio"}
                NavItem("⚙","Ajustes",tab=="Ajustes"){tab="Ajustes"}
                NavItem("♙","Admins",tab=="Admins"){tab="Admins"}
                NavItem("✦","Recursos",tab=="Recursos"){tab="Recursos"}
            }
        }
    }
}

@Composable fun GlassCard(modifier: Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xE61B2942),Color(0xC9111727))))
        .border(1.dp,Brush.linearGradient(listOf(Color(0x665BCFFF),Color(0x22FFFFFF))),RoundedCornerShape(24.dp))
        .padding(18.dp),content=content)
}
@Composable fun SectionTitle(title:String,tag:String) {
    Column { Text(tag,color=Cyan,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.8.sp); Spacer(Modifier.height(5.dp)); Text(title,fontSize=22.sp,fontWeight=FontWeight.ExtraBold) }
}
@Composable fun Label(s:String) { Text(s,color=Cyan,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.2.sp) }
@Composable fun InputField(value:String,onValue:(String)->Unit,placeholder:String,numeric:Boolean=false) {
    BasicTextField(value=value,onValueChange=onValue,singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=if(numeric) KeyboardType.Number else KeyboardType.Text),
        textStyle=androidx.compose.ui.text.TextStyle(color=White,fontSize=15.sp),
        modifier=Modifier.fillMaxWidth().padding(top=9.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF0B1120)).border(1.dp,Border,RoundedCornerShape(13.dp)).padding(14.dp),
        decorationBox={inner->Box { if(value.isEmpty()) Text(placeholder,color=Muted,fontSize=14.sp); inner() }})
}
@Composable fun SettingToggle(title:String,desc:String,checked:Boolean,onChange:(Boolean)->Unit) {
    Row(verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.SemiBold); Spacer(Modifier.height(3.dp)); Text(desc,color=Muted,fontSize=12.sp,lineHeight=17.sp) }
        Switch(checked=checked,onCheckedChange=onChange,colors=SwitchDefaults.colors(checkedThumbColor=Bg,checkedTrackColor=Blue))
    }
}
@Composable fun MetricCard(title:String,value:String,icon:String,modifier:Modifier=Modifier) {
    GlassCard(modifier) { Text(icon,color=Cyan,fontSize=22.sp); Spacer(Modifier.height(10.dp)); Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.2.sp); Text(value,fontSize=20.sp,fontWeight=FontWeight.ExtraBold) }
}
@Composable fun QuickCard(icon:String,title:String,desc:String,modifier:Modifier=Modifier,onClick:()->Unit) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Panel).border(1.dp,Border,RoundedCornerShape(20.dp)).clickable{onClick()}.padding(15.dp)) {
        Text(icon,color=Cyan,fontSize=23.sp); Spacer(Modifier.height(9.dp)); Text(title,fontWeight=FontWeight.Bold); Text(desc,color=Muted,fontSize=12.sp)
    }
}
@Composable fun ResourceCard(icon:String,title:String,desc:String) {
    GlassCard { Row(verticalAlignment=Alignment.Top) { Text(icon,color=Cyan,fontSize=27.sp); Spacer(Modifier.width(12.dp)); Column { Text(title,fontSize=16.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(7.dp)); Text(desc,color=Muted,fontSize=13.sp,lineHeight=19.sp) } } }
}
@Composable fun NavItem(icon:String,label:String,selected:Boolean,onClick:()->Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).background(if(selected) Color(0x3336B7FF) else Color.Transparent).clickable{onClick()}.padding(horizontal=13.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Text(icon,fontSize=20.sp,color=if(selected) Cyan else Muted); Text(label,fontSize=10.sp,color=if(selected) White else Muted,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
    }
}
