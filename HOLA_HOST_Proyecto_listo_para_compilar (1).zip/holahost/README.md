# HOLA HOST — Android project by Francisco

Interfaz Android nativa con Jetpack Compose, tema negro/azul eléctrico y panel estilo glass.

## Abrir y compilar
1. Instala Android Studio y un JDK compatible con Android Gradle Plugin 8.9.
2. Abre la carpeta `HOLA_HOST_Android` en Android Studio.
3. Deja que Gradle sincronice y descargue dependencias.
4. Conecta un teléfono Android o crea un emulador.
5. Usa Build > Build APK(s). El APK de depuración suele aparecer en `app/build/outputs/apk/debug/app-debug.apk`.

## Estado real de esta entrega
- Es un proyecto Android nativo (Kotlin + Jetpack Compose), no un sitio web.
- Funcionan localmente la navegación, campos de configuración, toggles, límite editable y lista de admins de ejemplo.
- Aún NO inicia un servidor Bedrock real, no acepta jugadores, no abre puertos, ni aplica permisos a un mundo. Esas funciones requieren integrar y probar un motor compatible con Android.
- El servidor oficial Bedrock Dedicated Server se distribuye oficialmente para Windows y Ubuntu Linux, no Android. La app oficial no puede simplemente ejecutarlo como un APK.
- Alternativas como PocketMine-MP son software de servidor diferente y no equivalen a vanilla Bedrock; hay que validar compatibilidad de versión, mundos y funciones antes de integrar.

## Notas
Para hacerlo servidor público desde el propio móvil, faltan motor compatible, proceso persistente/foreground service, gestión de almacenamiento de mundos, permisos, red UDP/19132, pruebas en el dispositivo y revisión de restricciones del operador/router. Una conexión móvil puede usar CGNAT y no aceptar conexiones entrantes.

## Obtener el APK automáticamente (sin instalar Android Studio)
1. Descomprime este ZIP.
2. Sube todos los archivos a un repositorio de GitHub (puede ser privado).
3. Abre la pestaña **Actions** y ejecuta **Build HOLA HOST APK** con **Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto **HOLA-HOST-debug-APK**. Dentro estará `app-debug.apk`.

Este flujo compila la app de interfaz. No convierte la interfaz en un servidor Bedrock real: las limitaciones indicadas arriba siguen aplicando.
